package com.example.basketballgame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class counter extends AppCompatActivity {
    int teama =0;
    int teamb=0;
    public void onepoint(View v)
    {
        teama = teama+1;
        displayForTeamA(teama);
    }
    public void twopoint(View v)
    {
        teama = teama+2;
        displayForTeamA(teama);
    }
    public void threepoint(View v)
    {
        teama = teama+3;
        displayForTeamA(teama);
    }
    public void onepointb(View v)
    {
        teamb = teamb+1;
        displayForTeamB(teamb);
    }
    public void twopointb(View v)
    {
        teamb = teamb+2;
        displayForTeamB(teamb);
    }
    public void threepointb(View v)
    {
        teamb = teamb+3;
        displayForTeamB(teamb);
    }
    public void reset(View v)
    {
        teama =0;
        teamb =0;
        displayForTeamB(teamb);
        displayForTeamA(teama);

    }

    public void displayForTeamA(int score) {
        TextView t1 = (TextView) findViewById(R.id.textView6);
        t1.setText(String.valueOf(score));
    }

    public void displayForTeamB(int score) {
        TextView t2 = (TextView) findViewById(R.id.textView7);
        t2.setText(String.valueOf(score));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counter);

    }
}
