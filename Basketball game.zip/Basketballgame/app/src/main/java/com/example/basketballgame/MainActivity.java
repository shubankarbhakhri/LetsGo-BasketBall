package com.example.basketballgame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    public void audio(){
         MediaPlayer media = MediaPlayer.create(this,R.raw.fuzzybeep);
         media.start();
    }

    public void about(View v)
{
    Intent in = new Intent(MainActivity.this,about.class);
    startActivity(in);
    audio();
}
    public void counter(View v)
    {
        Intent in = new Intent(MainActivity.this,counter.class);
        startActivity(in);
        audio();
    }
    public void play(View v)
    {
        Intent in = new Intent(MainActivity.this,play.class);
        startActivity(in);
        audio();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("info","app started");
    }
}
