package com.example.basketballgame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Random;

public class play extends AppCompatActivity {

    int teama = 0;
    int teamb = 0;
    public void reset(View view)
    {
        teama = 0;
        teamb = 0;
        displayforteamA(teama);
        displayforteamB(teamb);
    }
    public void teama(View v)
    {
        Random random = new Random();
        int value = random.nextInt(3) + 1;
        teama = teama + value;
        if(teama>=120)
        {
            Toast.makeText(this,"Team A wins",Toast.LENGTH_SHORT).show();
            reset(v);
        }
        else
            {
                displayforteamA(teama);
            }
    }

    private void displayforteamA(int value)
    {
        TextView text1 = (TextView) findViewById(R.id.textView14);
        text1.setText(String.valueOf(value));

    }

    public void teamb(View v)
    {
        Random rand = new Random();
        int value = rand.nextInt(3) + 1;
        teamb = teamb + value;
        if(teamb>120)
        {
            Toast.makeText(this,"Team B wins",Toast.LENGTH_SHORT).show();
            reset(v);
        }
        else
            {
                displayforteamB(teamb);
            }
    }
    private void displayforteamB(int value)
    {
        TextView text1 = (TextView) findViewById(R.id.textView16);
        text1.setText(String.valueOf(value));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

    }
}
